// Shared benchmark harness implementation. See vmbench.h for the API
// contract and the reasoning behind each piece.
#include "kernel/types.h"
#include "kernel/vmstats.h"
#include "kernel/fcntl.h"
#include "kernel/vmtrace.h"
#include "user/user.h"
#include "user/vmbench.h"
#include "user/zipf_table.h"

int vmbench_trace_on;
int vmbench_trace_fd = 1;      // console by default: unchanged behaviour
char vmbench_trace_buf[VMBENCH_TRACE_BUFSZ];
int vmbench_trace_len;

// Point the reference stream at a file when bit 3 is set. Returns 0 if the
// stream is left on the console or the file was opened, -1 if the file could
// not be created -- a caller that asked for a file sink and did not get one
// must fail rather than silently fall back to the console, because the run
// would then take three times as long and quietly blow its time limit.
int
vmbench_trace_sink(int flags)
{
  if((flags & VMBENCH_TRACE_FILE) == 0)
    return 0;
  int fd = open(VMBENCH_TRACE_PATH, O_CREATE | O_TRUNC | O_WRONLY);
  if(fd < 0)
    return -1;
  vmbench_trace_fd = fd;
  return 0;
}

long vmbench_trace_refs;
long vmbench_trace_bytes;

// A short write is fatal, not ignored. xv6's writei() refuses a write that
// would cross MAXFILE outright, so an oversized trace used to lose its whole
// tail silently while the run still printed PASS -- lzwbench's did, at 58%.
// Exiting here means no PASS, so the harness records the run as failed.
void
vmbench_trace_flush(void)
{
  if(vmbench_trace_len > 0){
    int n = write(vmbench_trace_fd, vmbench_trace_buf, vmbench_trace_len);
    if(n != vmbench_trace_len){
      printf("\nvmbench: trace write failed (%d of %d bytes) after %ld "
             "bytes and %ld references -- trace is incomplete\n",
             n, vmbench_trace_len, vmbench_trace_bytes, vmbench_trace_refs);
      exit(1);
    }
    vmbench_trace_bytes += n;
    vmbench_trace_len = 0;
  }
}

char *
vmbench_arena(int npages)
{
  return sbrklazy(npages * VMBENCH_PGSIZE);
}

void
vmbench_trace_start(const char *workload, const char *params, uint64 seed,
                     char *arena_base, int arena_pages,
                     int arena_cache_budget)
{
  vmctl(VM_PREFETCH_ENABLE, 0);
  struct vmstats s;
  vmbench_snapshot(&s);
  long arena_start_vpn = (long)((uint64)arena_base / VMBENCH_PGSIZE);
  printf("TRACEHDR workload=%s params=%s seed=%ld resident_limit=%ld "
         "arena_cache_budget=%d policy=%ld prefetch_enabled=0 "
         "arena_start_vpn=%ld arena_pages=%d\n",
         workload, params, (long)seed, s.resident_limit,
         arena_cache_budget, s.policy, arena_start_vpn, arena_pages);
  vmbench_trace_refs = 0;
  vmbench_trace_bytes = 0;
  vmbench_trace_on = 1;
}

void
vmbench_trace_stop(void)
{
  vmbench_trace_on = 0;
  vmbench_trace_flush();
  // What the workload believes it wrote. The host compares this against the
  // extracted file's line count and size, which catches loss anywhere after
  // the write() -- in the filesystem, the disk image, or the extraction.
  printf("TRACEEND refs=%ld bytes=%ld\n", vmbench_trace_refs,
         vmbench_trace_bytes);
}

int
vmbench_arena_free(int npages)
{
  return sbrk(-(npages * VMBENCH_PGSIZE)) == SBRK_ERROR ? -1 : 0;
}

void
vmbench_snapshot(struct vmstats *out)
{
  if(vmstats(out) < 0){
    printf("vmbench: vmstats() failed\n");
    exit(1);
  }
}

void
vmbench_reset_and_snapshot(struct vmstats *out)
{
  vmctl(VM_RESET_STATS, 0);
  vmbench_snapshot(out);
}

void
vmbench_delta(const struct vmstats *before, const struct vmstats *after,
              struct vmbench_delta *out)
{
  out->zero_faults = (long)after->zero_faults - (long)before->zero_faults;
  out->swap_faults = (long)after->swap_faults - (long)before->swap_faults;
  out->evictions = (long)after->evictions - (long)before->evictions;
  out->page_reads = (long)after->page_reads - (long)before->page_reads;
  out->page_writes = (long)after->page_writes - (long)before->page_writes;
  out->resident_count = (long)after->resident_count;
  out->free_swap_slots = (long)after->free_swap_slots;
  out->select_ticks = (long)after->select_ticks - (long)before->select_ticks;
  out->candidates_scanned =
    (long)after->candidates_scanned - (long)before->candidates_scanned;
  out->collect_ticks = (long)after->collect_ticks - (long)before->collect_ticks;
  out->path_ticks = (long)after->path_ticks - (long)before->path_ticks;
}

void
vmbench_print_delta(const char *label, const struct vmbench_delta *d)
{
  printf("[%s] zero_faults=%ld swap_faults=%ld evictions=%ld "
         "page_reads=%ld page_writes=%ld resident_count=%ld "
         "free_swap_slots=%ld select_ticks=%ld candidates_scanned=%ld "
         "collect_ticks=%ld path_ticks=%ld\n",
         label, d->zero_faults, d->swap_faults, d->evictions,
         d->page_reads, d->page_writes, d->resident_count,
         d->free_swap_slots, d->select_ticks, d->candidates_scanned,
         d->collect_ticks, d->path_ticks);
}

void
vmbench_result(const char *key, long value)
{
  printf("RESULT %s=%ld\n", key, value);
}

void
vmbench_banner(const char *workload, const char *phase)
{
  printf("\n== %s: %s ==\n", workload, phase);
}

void
vmbench_rng_seed(struct vmbench_rng *r, uint64 seed)
{
  r->state = seed ? seed : 0x9E3779B97F4A7C15ULL;
}

uint64
vmbench_rng_next(struct vmbench_rng *r)
{
  uint64 x = r->state;
  x ^= x << 13;
  x ^= x >> 7;
  x ^= x << 17;
  r->state = x;
  return x;
}

uint64
vmbench_rng_below(struct vmbench_rng *r, uint64 bound)
{
  if(bound == 0)
    return 0;
  return vmbench_rng_next(r) % bound;
}

uint64
vmbench_zipf_sample(struct vmbench_rng *r)
{
  uint32 draw = (uint32)vmbench_rng_next(r);
  int lo = 0, hi = VMBENCH_ZIPF_N - 1;
  while(lo < hi){
    int mid = lo + (hi - lo) / 2;
    if(vmbench_zipf_cdf[mid] >= draw)
      hi = mid;
    else
      lo = mid + 1;
  }
  return (uint64)lo;
}

static int
burn(char *arena_base, int arena_pages, uint64 *settled_resident)
{
  long arena_start_vpn = (long)arena_base / VMBENCH_PGSIZE;
  // Do not seize the trace ring if something else is already capturing
  // through it (vmdrain, say). Enabling and resetting it here wipes that
  // capture's buffered records and restarts its sequence numbering, and
  // the subsequent vmtrace_read() drain below eats records the other
  // reader never sees. The symptom downstream is a capture reporting
  // dropped=0 alongside sequence gaps -- 86 events vanished from a
  // 150-event capture of btreebench before this check existed.
  //
  // When the ring is already owned, take the best-effort path below
  // instead: the same fallback this function already documents for the
  // case where tracing is unavailable at all.
  struct vmtrace_header hdr;
  int ring_owned_elsewhere = vmtrace_info(&hdr) == 0 && hdr.enabled != 0;
  int tracing = !ring_owned_elsewhere && vmctl(VM_TRACE_ENABLE, 1) == 0;
  if(tracing)
    vmctl(VM_TRACE_RESET, 0);

  // Force a tight temporary budget ourselves -- don't rely on the
  // caller having already set one. If the process is still under
  // whatever limit it started with (possibly unlimited), nothing would
  // ever be evicted no matter how many scratch pages we touch, and the
  // burn could never observe a VICTIM_SELECTED event at all.
  struct vmstats current;
  vmbench_snapshot(&current);
  if(vmctl(VM_SET_LIMIT, (int)current.resident_count) < 0)
    return -1;

  int max_burn = 64;
  char *scratch = vmbench_arena(max_burn);
  if(scratch == SBRK_ERROR)
    return -1;

  if(tracing){
    int reached = 0;
    for(int i = 0; i < max_burn && !reached; i++){
      touch_w(scratch, i, 1);
      struct vmtrace_event ev[8];
      int n;
      while((n = vmtrace_read(ev, 8)) > 0){
        for(int j = 0; j < n; j++){
          // victim_vpn is uint32 as of the vmtrace schema v3 merge (was
          // uint64). A plain (long) cast would zero-extend a real
          // VMTRACE_NONE32 sentinel into a huge positive number instead
          // of -1 -- currently harmless here only because
          // VICTIM_SELECTED's victim_vpn is never actually the sentinel
          // (see kernel/vmpage.c's reclaim_frame()), not because this
          // code accounts for it. Route through the same NONE32 check
          // pagingdemo.c/policydemo.c use, for defense-in-depth.
          long victim_vpn = ev[j].victim_vpn == VMTRACE_NONE32
                               ? -1
                               : (long)ev[j].victim_vpn;
          if(ev[j].type == VMTRACE_VICTIM_SELECTED &&
             victim_vpn >= arena_start_vpn &&
             victim_vpn < arena_start_vpn + arena_pages){
            reached = 1;
            break;
          }
        }
      }
    }
    if(!reached){
      vmbench_arena_free(max_burn);
      return -1;
    }
  } else {
    // Best-effort fallback: no trace ring to prove the burn actually
    // reached the arena, so just touch a generous, fixed number of
    // scratch pages and hope for the best. Callers must warn that this
    // guarantee is weaker than the VM_DEBUG path.
    for(int i = 0; i < max_burn; i++)
      touch_w(scratch, i, 1);
  }

  if(vmbench_arena_free(max_burn) < 0)
    return -1;

  struct vmstats settled;
  vmbench_snapshot(&settled);
  *settled_resident = settled.resident_count;

  return tracing;
}

// The burn sizes the process's baseline -- the settled resident count the
// caller adds its margin to -- by evicting, so the result depends on which
// policy chooses the victims: with vmrun selecting the policy, Clock settled
// at 13 resident pages, Aging at 9 and a learned policy at 28 for the same
// matmul run, which would hand each policy a different memory size. Run the
// burn under FIFO (the default every trace was collected with) and restore
// the process's own policy after, so every policy gets the same limit.
int
vmbench_burn(char *arena_base, int arena_pages, uint64 *settled_resident)
{
  struct vmstats st;
  vmbench_snapshot(&st);
  int policy = (int)st.policy;
  if(vmctl(VM_SET_POLICY, VM_POLICY_FIFO) < 0)
    return -1;
  int r = burn(arena_base, arena_pages, settled_resident);
  if(vmctl(VM_SET_POLICY, policy) < 0)
    return -1;
  return r;
}
