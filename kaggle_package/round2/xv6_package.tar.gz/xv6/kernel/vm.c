#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "elf.h"
#include "riscv.h"
#include "defs.h"
#include "spinlock.h"
#include "proc.h"
#include "fs.h"
#include "vmpage.h"
#include "vm.h"
#include "swap.h"
#include "vmtrace.h"

/*
 * the kernel's page table.
 */
pagetable_t kernel_pagetable;

extern char etext[]; // kernel.ld sets this to end of kernel code.

extern char trampoline[]; // trampoline.S

// Make a direct-map page table for the kernel.
pagetable_t
kvmmake(void)
{
  pagetable_t kpgtbl;

  kpgtbl = (pagetable_t)kalloc();
  memset(kpgtbl, 0, PGSIZE);

  // uart registers
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);

  // virtio mmio disk interface
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);

  // PLIC
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);

  // map kernel text executable and read-only.
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);

  // map kernel data and the physical RAM we'll make use of.
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
         PTE_R | PTE_W);

  // map the trampoline for trap entry/exit to
  // the highest virtual address in the kernel.
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);

  // allocate and map a kernel stack for each process.
  proc_mapstacks(kpgtbl);

  return kpgtbl;
}

// add a mapping to the kernel page table.
// only used when booting.
// does not flush TLB or enable paging.
void
kvmmap(pagetable_t kpgtbl, uint64 va, uint64 pa, uint64 sz, int perm)
{
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    panic("kvmmap");
}

// Initialize the kernel_pagetable, shared by all CPUs.
void
kvminit(void)
{
  kernel_pagetable = kvmmake();
}

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));

  // flush stale entries from the TLB.
  sfence_vma();
}

// Return the address of the PTE in page table pagetable
// that corresponds to virtual address va.  If alloc!=0,
// create any required page-table pages.
//
// The risc-v Sv39 scheme has three levels of page-table
// pages. A page-table page contains 512 64-bit PTEs.
// A 64-bit virtual address is split into five fields:
//   39..63 -- must be zero.
//   30..38 -- 9 bits of level-2 index.
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
  if (va >= MAXVA)
    panic("walk");

  for (int level = 2; level > 0; level--) {
    pte_t *pte = &pagetable[PX(level, va)];
    if (*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
}

// Look up a virtual address, return the physical address,
// or 0 if not mapped.
// Can only be used to look up user pages.
uint64
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    return 0;

  pte = walk(pagetable, va, 0);
  if (pte == 0)
    return 0;
  if ((*pte & PTE_V) == 0)
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa.
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    panic("mappages: size not aligned");

  if (size == 0)
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
  for (;;) {
    if ((pte = walk(pagetable, a, 1)) == 0)
      return -1;
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
  if (pagetable == 0)
    return 0;
  memset(pagetable, 0, PGSIZE);
  return pagetable;
}

// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
      continue;
    if ((*pte & PTE_V) == 0){
      if(*pte & PTE_SWAPPED){
        // Reaching a BUSY (in-flight fetch/prefetch) leaf here is a real
        // invariant violation, not just a defensive check: uvmunmap() must
        // never be called with unresolved I/O still owning a PTE in this
        // pagetable. The one caller that reaches user teardown, kexit(),
        // relies on vm_prefetch_drain() running first (see the comment
        // there) to guarantee no BUSY leaf remains by the time a pagetable
        // is actually freed. If a future change reorders exit/kill cleanup,
        // this should fail loudly right here rather than silently leaking
        // or corrupting the swap slot this PTE still names.
        if(*pte & PTE_BUSY)
          panic("uvmunmap: busy");
        int slot = PTE2SLOT(*pte);
        uint64 flags = PTE_FLAGS(*pte);
        if(swap_slot_put(slot) < 0)
          panic("uvmunmap: swap slot");
        *pte = 0;
        struct proc *tracep = myproc();
        if(tracep && tracep->pagetable == pagetable)
          vmtrace_emit(tracep, VMTRACE_UNMAP, a, -1, -1, flags,
                       VMTRACE_NONE, slot, VMTRACE_NONE, VMTRACE_NONE, 0);
      }
      continue;
    }
    uint64 flags = PTE_FLAGS(*pte);
    uint64 pa = PTE2PA(*pte);
    if (do_free) {
      if(vm_frame_release(pa) < 0)
        kfree((void *)pa);
    }
    *pte = 0;
    struct proc *tracep = myproc();
    if(tracep && tracep->pagetable == pagetable)
      vmtrace_emit(tracep, VMTRACE_UNMAP, a, -1, -1, flags,
                   (pa - KERNBASE) / PGSIZE, -1, VMTRACE_NONE,
                   VMTRACE_NONE, 0);
  }
}

// Allocate PTEs and physical memory to grow a process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
uint64
uvmalloc(struct proc *p, pagetable_t pagetable, uint64 oldsz, uint64 newsz,
          int xperm)
{
  uint64 mem;
  uint64 a;

  if (newsz < oldsz)
    return oldsz;

  oldsz = PGROUNDUP(oldsz);
  for (a = oldsz; a < newsz; a += PGSIZE) {
    if(vm_frame_acquire(p, pagetable, a, VM_FRAME_CONSTRUCTION, &mem) !=
       VM_FRAME_OK){
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
    memset((void *)mem, 0, PGSIZE);
    if (mappages(pagetable, a, PGSIZE, mem, PTE_R | PTE_U | xperm) !=
        0) {
      vm_frame_release(mem);
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
    vm_frame_unpin(mem);
  }
  return newsz;
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if (newsz >= oldsz)
    return oldsz;

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    pte_t pte = pagetable[i];
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if (pte & PTE_V) {
      panic("freewalk: leaf");
    } else if(pte & (PTE_SWAPPED | PTE_BUSY)) {
      panic("freewalk: swapped leaf");
    }
  }
  kfree((void *)pagetable);
}

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
  if (sz > 0)
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
}

// Given a parent process's page table, copy
// its memory into a child's page table.
// Copies both the page table and the
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.
int
uvmcopy(struct proc *oldp, struct proc *newp, pagetable_t old,
        pagetable_t new, uint64 sz)
{
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  uint64 mem;

  (void)oldp;

  for (i = 0; i < sz; i += PGSIZE) {
  retry:
    if ((pte = walk(old, i, 0)) == 0)
      continue; // page table entry hasn't been allocated
    if ((*pte & PTE_V) == 0){
      if(*pte & PTE_BUSY){
        // The only source of PTE_BUSY on a page this process isn't itself
        // touching is the async prefetch worker mid-fetch. Wait for it to
        // resolve -- installed, or reverted back to SWAPPED on
        // cancellation/error -- instead of failing the whole fork; every
        // terminal outcome in prefetch.c wakes this exact channel. This
        // mirrors vmfault()'s identical wait-and-retry on the same PTE.
        sleep_prepare(pte);
        sleep();
        goto retry;
      }
      if(*pte & PTE_SWAPPED){
        int slot = PTE2SLOT(*pte);
        if(swap_slot_get(slot) < 0)
          goto err;
        pte_t *childpte = walk(new, i, 1);
        if(childpte == 0 || *childpte != 0){
          swap_slot_put(slot);
          goto err;
        }
        *childpte = *pte;
      }
      continue;
    }
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if(vm_frame_pin(pa) < 0)
      goto err;
    if (vm_frame_acquire(newp, new, i, VM_FRAME_CONSTRUCTION, &mem) !=
        VM_FRAME_OK){
      vm_frame_unpin(pa);
      goto err;
    }
    memmove((void *)mem, (char *)pa, PGSIZE);
    vm_frame_unpin(pa);
    if (mappages(new, i, PGSIZE, mem, flags) != 0) {
      vm_frame_release(mem);
      goto err;
    }
    vm_frame_unpin(mem);
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
  return -1;
}

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;

  pte = walk(pagetable, va, 0);
  if (pte == 0)
    panic("uvmclear");
  *pte &= ~PTE_U;
}

// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
int
copyout(pagetable_t pagetable, uint64 psz, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while (len > 0) {
    va0 = PGROUNDDOWN(dstva);
    if (va0 >= MAXVA)
      return -1;

    pa0 = walkaddr(pagetable, va0);
    if (pa0 == 0) {
      if ((pa0 = vmfault(pagetable, psz, va0, VM_ACCESS_WRITE)) == 0) {
        return -1;
      }
    }

    pte = walk(pagetable, va0, 0);
    // forbid copyout over read-only user text pages.
    if ((*pte & PTE_W) == 0)
      return -1;
    *pte |= PTE_A | PTE_D;
    vm_frame_note_access(pa0, 1);

    n = PGSIZE - (dstva - va0);
    if (n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);

    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}

// Copy from user to kernel.
// Copy len bytes to dst from virtual address srcva in a given page table.
// Return 0 on success, -1 on error.
int
copyin(pagetable_t pagetable, uint64 psz, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while (len > 0) {
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if (pa0 == 0) {
      if ((pa0 = vmfault(pagetable, psz, va0, VM_ACCESS_READ)) == 0) {
        return -1;
      }
    }
    pte_t *pte = walk(pagetable, va0, 0);
    if(pte)
      *pte |= PTE_A;
    vm_frame_note_access(pa0, 0);
    n = PGSIZE - (srcva - va0);
    if (n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);

    len -= n;
    dst += n;
    srcva = va0 + PGSIZE;
  }
  return 0;
}

// Copy a null-terminated string from user to kernel.
// Copy bytes to dst from virtual address srcva in a given page table,
// until a '\0', or max.
// Return 0 on success, -1 on error.
int
copyinstr(pagetable_t pagetable, uint64 psz, char *dst, uint64 srcva,
          uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while (got_null == 0 && max > 0) {
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if (pa0 == 0) {
      if ((pa0 = vmfault(pagetable, psz, va0, VM_ACCESS_READ)) == 0) {
        return -1;
      }
    }
    pte_t *pte = walk(pagetable, va0, 0);
    if(pte)
      *pte |= PTE_A;
    vm_frame_note_access(pa0, 0);
    n = PGSIZE - (srcva - va0);
    if (n > max)
      n = max;

    char *p = (char *)(pa0 + (srcva - va0));
    while (n > 0) {
      if (*p == '\0') {
        *dst = '\0';
        got_null = 1;
        break;
      } else {
        *dst = *p;
      }
      --n;
      --max;
      p++;
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if (got_null) {
    return 0;
  } else {
    return -1;
  }
}

// allocate and map user memory if process is referencing a page
// that was lazily allocated in sys_sbrk().
// returns 0 if va is invalid or already mapped, or if
// out of physical memory, and physical address if successful.
uint64
vmfault(pagetable_t pagetable, uint64 psz, uint64 va, int access)
{
  if (va >= psz)
    return 0;
  va = PGROUNDDOWN(va);
  struct proc *p = myproc();
  if(p == 0)
    return 0;
  int waited_for_fetch = 0;

retry:
  pte_t *pte = walk(pagetable, va, 0);
  if(pte && (*pte & PTE_V)){
    uint flags = PTE_FLAGS(*pte);
    int allowed = (flags & PTE_U) &&
      ((access == VM_ACCESS_READ && (flags & PTE_R)) ||
       (access == VM_ACCESS_WRITE && (flags & PTE_W)) ||
       (access == VM_ACCESS_EXEC && (flags & PTE_X)));
    if(waited_for_fetch && allowed){
      *pte |= PTE_A | (access == VM_ACCESS_WRITE ? PTE_D : 0);
      sfence_vma();
      uint64 pa = PTE2PA(*pte);
      vm_frame_note_access(pa, access == VM_ACCESS_WRITE);
      return pa;
    }
    acquire(&p->vm.lock);
    p->vm.stats.protection_faults++;
    release(&p->vm.lock);
    vmtrace_emit(p, VMTRACE_PROTECTION_FAULT, va, access, -1,
                 PTE_FLAGS(*pte), (PTE2PA(*pte) - KERNBASE) / PGSIZE, -1,
                 VMTRACE_NONE, VMTRACE_NONE, -1);
    return 0;
  }

  if(pte && (*pte & PTE_SWAPPED)){
    if(*pte & PTE_BUSY){
      acquire(&p->vm.lock);
      p->vm.stats.prefetch_late++;
      release(&p->vm.lock);
      waited_for_fetch = 1;
      sleep_prepare(pte);
      sleep();
      goto retry;
    }
    uint flags = PTE_FLAGS(*pte) & ~(PTE_V | PTE_SWAPPED | PTE_BUSY);
    int allowed = (flags & PTE_U) &&
      ((access == VM_ACCESS_READ && (flags & PTE_R)) ||
       (access == VM_ACCESS_WRITE && (flags & PTE_W)) ||
       (access == VM_ACCESS_EXEC && (flags & PTE_X)));
    if(!allowed){
      acquire(&p->vm.lock);
      p->vm.stats.protection_faults++;
      release(&p->vm.lock);
      vmtrace_emit(p, VMTRACE_PROTECTION_FAULT, va, access, -1, flags,
                   VMTRACE_NONE, PTE2SLOT(*pte), VMTRACE_NONE,
                   VMTRACE_NONE, -1);
      return 0;
    }
    int slot = PTE2SLOT(*pte);
    vmtrace_emit(p, VMTRACE_SWAP_FAULT, va, access, -1, flags,
                 VMTRACE_NONE, slot, VMTRACE_NONE, VMTRACE_NONE, 0);
    *pte |= PTE_BUSY;
    uint64 mem;
    while(vm_frame_acquire(p, pagetable, va, VM_FRAME_DEMAND, &mem) !=
          VM_FRAME_OK){
      acquire(&p->vm.lock);
      int prefetch_inflight = p->vm.inflight_io != 0;
      release(&p->vm.lock);
      if(!prefetch_inflight || killed(p)){
#ifdef VM_DEBUG
        printk("vmfault: frame acquire failed pid=%d va=0x%lx resident=%ld limit=%ld\n",
               p->pid, va, p->vm.resident_count, p->vm.resident_limit);
#endif
        *pte &= ~PTE_BUSY;
        wakeup(pte);
        return 0;
      }
      sleep_prepare(&p->vm.inflight_io);
      acquire(&p->vm.lock);
      prefetch_inflight = p->vm.inflight_io != 0;
      release(&p->vm.lock);
      if(prefetch_inflight)
        sleep();
      else
        wakeup(&p->vm.inflight_io);
    }
    vmtrace_emit(p, VMTRACE_SWAP_READ_BEGIN, va, access, -1, flags,
                 (mem - KERNBASE) / PGSIZE, slot, VMTRACE_NONE,
                 VMTRACE_NONE, 0);
    if(swap_page_read(slot, mem) < 0){
      vmtrace_emit(p, VMTRACE_SWAP_READ_END, va, access, -1, flags,
                   (mem - KERNBASE) / PGSIZE, slot, VMTRACE_NONE,
                   VMTRACE_NONE, -1);
      vm_frame_release(mem);
      *pte = SLOT2PTE(slot) | flags | PTE_SWAPPED;
      wakeup(pte);
      return 0;
    }
    vmtrace_emit(p, VMTRACE_SWAP_READ_END, va, access, -1, flags,
                 (mem - KERNBASE) / PGSIZE, slot, VMTRACE_NONE,
                 VMTRACE_NONE, 0);
    if((*pte & (PTE_SWAPPED | PTE_BUSY)) !=
       (PTE_SWAPPED | PTE_BUSY) || PTE2SLOT(*pte) != slot){
      vm_frame_release(mem);
      wakeup(pte);
      return 0;
    }
    uint accessed = PTE_A;
    if(access == VM_ACCESS_WRITE)
      accessed |= PTE_D;
    *pte = PA2PTE(mem) | flags | accessed | PTE_V;
    sfence_vma();
    if(vm_frame_set_backing(mem, slot) < 0)
      panic("vmfault backing");
    vm_frame_unpin(mem);
    vmtrace_emit(p, VMTRACE_MAP, va, access, VM_PAGE_RESIDENT_DEMAND, flags,
                 (mem - KERNBASE) / PGSIZE, slot, VMTRACE_NONE,
                 VMTRACE_NONE, 0);
    acquire(&p->vm.lock);
    p->vm.stats.swap_faults++;
    int predict_next = p->vm.prefetch_enabled && p->vm.prefetch_automatic &&
      !p->vm.exiting;
    release(&p->vm.lock);
    wakeup(pte);
    if(predict_next && va + PGSIZE < p->sz &&
       vm_prefetch_hint(p, va + PGSIZE, 1) == 0)
      vm_prefetch_service(p, 1);
    return mem;
  }

  if(pte && *pte != 0)
    return 0;
  if(access == VM_ACCESS_EXEC){
    vmtrace_emit(p, VMTRACE_PROTECTION_FAULT, va, access, -1, 0,
                 VMTRACE_NONE, -1, VMTRACE_NONE, VMTRACE_NONE, -1);
    return 0;
  }
  uint64 mem;
  if(vm_frame_acquire(p, pagetable, va, VM_FRAME_DEMAND, &mem) != VM_FRAME_OK)
    return 0;
  memset((void *)mem, 0, PGSIZE);
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    vm_frame_release(mem);
    return 0;
  }
  vm_frame_unpin(mem);
  pte = walk(pagetable, va, 0);
  if(pte)
    *pte |= PTE_A | (access == VM_ACCESS_WRITE ? PTE_D : 0);
  acquire(&p->vm.lock);
  p->vm.stats.zero_faults++;
  release(&p->vm.lock);
  vmtrace_emit(p, VMTRACE_ZERO_FAULT, va, access,
               VM_PAGE_RESIDENT_DEMAND, PTE_W | PTE_U | PTE_R,
               (mem - KERNBASE) / PGSIZE, -1, VMTRACE_NONE,
               VMTRACE_NONE, 0);
  vmtrace_emit(p, VMTRACE_MAP, va, access, VM_PAGE_RESIDENT_DEMAND,
               PTE_W | PTE_U | PTE_R, (mem - KERNBASE) / PGSIZE, -1,
               VMTRACE_NONE, VMTRACE_NONE, 0);
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
  pte_t *pte = walk(pagetable, va, 0);
  if (pte == 0) {
    return 0;
  }
  if (*pte & PTE_V) {
    return 1;
  }
  return 0;
}
